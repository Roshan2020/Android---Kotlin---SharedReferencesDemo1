package com.example.sharedreferencesdemo1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.sharedreferencesdemo1.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    var binding: ActivityMainBinding? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding!!.root)
    }

    override fun onResume() {
        super.onResume()
        var sharedRef = getSharedPreferences("MyRef", MODE_PRIVATE)
        var name = sharedRef.getString("name","")
        var age = sharedRef.getInt("age", 0)
        binding!!.name.setText(name)
        binding!!.age.setText(age.toString())
    }

    override fun onPause() {
        super.onPause()
        var sharedRef = getSharedPreferences("MyRef", MODE_PRIVATE)
        var edit = sharedRef.edit()
        edit.putString("name", binding!!.name.editableText.toString())
        edit.putInt("age", binding!!.age.editableText.toString().toInt())
        edit.apply()
    }
}